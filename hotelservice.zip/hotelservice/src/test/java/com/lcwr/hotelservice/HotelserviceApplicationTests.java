package com.lcwr.hotelservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
